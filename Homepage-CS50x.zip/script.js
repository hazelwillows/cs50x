var input = document.getElementById("hidden");
input.addEventListener("mouseover", function() {
  input.style.color = "white";
})

input.addEventListener("mouseout", function() {
  input.style.color = "#37aea0";
});

var b = document.getElementById("button");
var t = document.getElementById("text");
b.addEventListener("click", function () {
  if (t.style.display == "block") {
    t.style.display = "none";
  } else {
    t.style.display = "block";
  }
})